
#include <stdio.h>
#include<stdlib.h>
#include<math.h>
#include "mpi.h"
main(int argc, char** argv)  
{
int my_rank;
int p,pl,i,j,target,num,res,source,sum,maxp,MAX;
int tag1=50, tag2=60, tag3=70,tag4=80,tag5=90,tag6=100;
int data[100],data1[100],d_local[100],d[100];
float m;
MPI_Status status;
/* sunartisi arxikopoieisis MPI*/
MPI_Init(&argc, &argv);
/* epistrofi tis tautotitas kathe diergasias*/
MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
/* epistrofi tou sinolikou plithous twn diergasiwn*/
MPI_Comm_size(MPI_COMM_WORLD, &p);
/*an einai mideniki diergasia */
if (my_rank == 0)  {
       printf("Dose plithos aritmon:\n");
       scanf("%d", &pl);
       printf("Dose tous %d arithmous:\n", pl); 
       /*dinoume times se enan pinaka*/ 
       for (j=0; j<pl; j++)
       scanf("%d", &data[j]);
       /*stelnoume stis diergasies to plithos twn arithmwn pou dothikan*/
       for (target = 1; target < p; target++) 
           MPI_Send(&pl, 1, MPI_INT, target, tag1, MPI_COMM_WORLD);
      /*ypologizoume to plithos arithmwn kathe diergasias*/
      num = pl/p;  
      j=num;
      /*stelnoume tous arithmous stis diergasies*/
      for (target = 1; target < p; target++)  {
         MPI_Send(&data[j], num, MPI_INT, target, tag2, MPI_COMM_WORLD);
         j+=num;  }
      /*ftiaxnoume topiko pinaka kathe diergasias*/
      for (j=0; j<num; j++)
         data1[j]=data[j];
}
   else {
   	   /*oi diergasies lamvanoun to plithos twn arithmwn*/
       MPI_Recv(&pl, 1, MPI_INT, 0, tag1, MPI_COMM_WORLD, &status);
       num = pl/p;
       /*diergasies lamvanoun ton topiko pinaka*/
       MPI_Recv(&data1[0], num, MPI_INT, 0, tag2, MPI_COMM_WORLD, &status);
     }   
 //ypologismos mesi timis
 res = 0;
 /*prosthetoume tous arithmous tou topikou pinaka kathe diergasias*/
 for (j=0; j<num; j++)
        res = res + data1[j];   
/*ean i diergasia den einai i mideniki tote stelnei to athrisma */
 if (my_rank != 0)  {
       MPI_Send(&res, 1, MPI_INT, 0, tag3, MPI_COMM_WORLD);
}
/*ean einai einai i mideniki diergasia*/
 else  {
       sum = res;
       printf("\n Apotelesma of process %d: %d\n", my_rank, res);
       /*oi diergasies lamvanoun to athrisma twn arithmwn tou topikou pinaka*/
       for (source = 1; source < p; source++)  {
       	   /*oi diergasies lamvanoun to athrisma twn arithmwn tou topikou pinaka*/
           MPI_Recv(&res, 1, MPI_INT, source, tag3, MPI_COMM_WORLD, &status);
           /*athrizoume to athrisma olwn twn diergasiwn*/
           sum = sum+ res;
           printf("\n Apotelesma of process %d: %d\n", source, res);
        }
        /*upologismos mesis timis*/
        m=(float)sum/pl;
    printf("\n\n\n mesi timi: %f\n", m);
   }
 // ypologismos max
 /*thewroume arxika ws max arithmo tou topikou pinaka diergasias to prwto stoixeio*/
   maxp=data1[0];
 for (j=1; j<num; j++)
 {
 	/*gia kathe stoixeio tou topikou pinaka elegxoume an einai megalutero apo kathe allo an einai thetoume max*/
     if(maxp<data1[j])
        maxp=data1[j];
 } 
 /*ean den einai i mideniki diergasia stelnei to max stoixeio tou topikou pinaka*/
   if (my_rank != 0)  {
       MPI_Send(&maxp, 1, MPI_INT, 0, tag4, MPI_COMM_WORLD);
    }
    else  {
    	 /*diaforetika thetoume stin metavliti MAX ton megalutero arithmo tou topikou pinaka kathe diergasias*/
       MAX= maxp;
       printf("\n Apotelesma of process %d: %d\n", my_rank, maxp);
       /*kathe diergasia lamvanei to megalutero arithmo tou topikou pinaka*/
       for (source = 1; source < p; source++)  {
           MPI_Recv(&maxp, 1, MPI_INT, source, tag4, MPI_COMM_WORLD, &status);
           /*ean einai i prwti diergasia thetoume megalutero arithmo olwn twn diergasiwn to max tou topikou tis pinaka*/
           if(source==1)
                MAX=maxp;
           /*elegxoume ean kapoio max kathe diergasias einai megalutero apo kapoio allo an einai thetoume ws MAX*/ 
           else
            {
               if(maxp>MAX)
                  MAX=maxp;
            }
           printf("\n Apotelesma of process %d: %d\n", source,maxp);
     }
    printf("\n\n\n megisti timi: %d\n", MAX);
   }
   //ypologismos dianismatos d
   /*ean einai i mideniki diergasia stelnei to megalutero arithmo apo oles tis diergasies*/
       if (my_rank == 0)  {
      for (target = 1; target < p; target++)  
       MPI_Send(&MAX, 1, MPI_INT, target, tag5, MPI_COMM_WORLD);
    }
    /*diaforetika oi diergasies lamvanoun to megalutero arithmo apo oles tis diergasies*/
    else
    {
        MPI_Recv(&MAX, 1, MPI_INT, 0, tag5, MPI_COMM_WORLD, &status);
    } 
    /*upologismos tou topikou dianismatos d kathe diergasias*/
    for(i=0;i<num;i++)
    {
                int diff=abs(data1[i]-MAX);
                d_local[i]=diff*diff;
    }
    /*ean i diergasia den einai i mideniki stelnei to topiko dianisma d kathe diergasias*/
    if(my_rank!=0)
    {
          MPI_Send(d_local,num, MPI_INT,0,tag6, MPI_COMM_WORLD);
     }
     else
     {
     	/*diaforetika gemizoumwe s enan pinaka ta topika dianimsata d olwn twn diergasiwn*/
          for(i=0;i<num;i++)
          {
              d[i]=d_local[i];
          }
          /*oi diergasies lamvannoun to dianisma d*/
          for (target = 1; target < p; target++)  {
             MPI_Recv(&d[target*num],num, MPI_INT,target,tag6,MPI_COMM_WORLD,&status);
       }   
       /*emsanisi tou dianismatos d stin othoni*/
       for (i=0; i<pl; i++)
              {
                    printf("\n dianisma d  %d\n",d[i]);
              }
    }
   MPI_Finalize();
   return 0;
}    
        

